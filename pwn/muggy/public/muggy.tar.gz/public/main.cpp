#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
#include <memory>
#include <fstream>  
long name_sz = 0x30;
char* str = new char[0x200];

class Factory {
private:
    char magic[16];
    char* name_;
    u_int64_t fun_ = 0;

public:
    Factory(const char* str = "") {
        name_ = new char[name_sz+ 1];
        std::strcpy(name_, str);
    }

    // ~Factory() {
    //     delete[] name_;
    // }

    void setName(const char* str) {
        std::strcpy(name_, str);
    }

    // Print the string representation of the object
    void print() const {
        if (!fun_)
            std::cout << "Factory name(" << name_ << ")" << std::endl;
        else
            std::cout << "Fun Factory name(" << name_ << ")" << std::endl;
    }

    void factor() {
        if (fun_ == 0) {
            std::cout << "Nope" << std::endl;
            return;
        }

        char a[] = {'s','u','p','e','r','s','e','c','u','r','e','\0'};

        // Reverse the factory's name        
        for (int i=0;i<strlen(name_)+1; i++){
            str[i] = name_[i] ^ a[i];
        }

        // Simulate a production process
        std::cout << "Producing with factory: " << name_ << std::endl;
        std::cout << "Xored name: " << str << std::endl;

        delete[] str;
    }

    void makeFunctionable() {
        fun_ = 1;
    }
};

void menu() {
    std::cout << "1. Create new Factory" << std::endl;
    std::cout << "2. Change Factory name" << std::endl;
    std::cout << "3. Change Fun Factory name" << std::endl;
    std::cout << "4. Make Factory functionable" << std::endl;
    std::cout << "5. List all Factories" << std::endl;
    std::cout << "6. List all Fun Factories" << std::endl;
    std::cout << "7. Delete a Factory" << std::endl;
    std::cout << "8. Factor a Factory" << std::endl;

    std::cout << "0. Exit" << std::endl;
}

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);

    std::vector<Factory*> factories;
    std::vector<Factory*> fun_factories;
    int choice;

    while (true) {
        menu();
        std::cout << "> ";
        std::cin >> choice;
        if (std::cin.eof()){
            return 0;
        }
        switch (choice) {
            case 1: {
                std::cout << "Enter Factory name: ";
                char name[0x100];
                std::cin.ignore();
                std::cin.getline(name, 0x100);
                Factory *factor = new Factory(name);
                std::cin.clear();
                factories.emplace_back(factor);
                break;
            }
            case 2: {
                std::cout << "Enter Factory index to change name: ";
                size_t index;
                std::cin >> index;
                if (index < factories.size()) {
                    std::cout << "Enter new name: ";
                    char newName[0x100];
                    std::cin.ignore();
                    std::cin.getline(newName, 0x100);
                    std::cin.clear();
                    std::cin.ignore();
                    factories[index]->setName(newName);
                } else {
                    std::cout << "Invalid index." << std::endl;
                }
                break;
            }
            case 3: {
                std::cout << "Enter Fun Factory index to change name: ";
                size_t index;
                std::cin >> index;
                if (index < fun_factories.size()) {
                    std::cout << "Enter new name: ";
                    char newName[100];
                    std::cin.ignore();
                    std::cin.getline(newName, 100);
                    fun_factories[index]->setName(newName);
                } else {
                    std::cout << "Invalid index." << std::endl;
                }
                break;
            }
            case 4: {
                std::cout << "Enter Factory index to make fun: ";
                size_t index;
                std::cin >> index;
                if (index< factories.size()) {
                    factories[index]->makeFunctionable();
                    fun_factories.push_back(factories[index]);
                }
                break;   
            }
            case 5: {
                for (size_t i = 0; i < factories.size(); ++i) {
                    std::cout << "Factory " << i << ": ";
                    factories[i]->print();
                }

                break;
            }
            case 6: {
                for (size_t i = 0; i < fun_factories.size(); ++i) {
                    std::cout << "Fun Factory " << i << ": ";
                    fun_factories[i]->print();
                }
                break;
            }
            case 7: {
                std::cout << "Enter Factory index to delete factory: ";
                size_t index;
                std::cin >> index;
                if (index< factories.size()) {
                    delete factories[index];
                    factories.erase(factories.begin() + index);
                }
                break;
            }

            case 8: {
                std::cout << "Enter Factory index to factor factory: ";
                size_t index;
                std::cin >> index;
                if (index< fun_factories.size()) {
                    fun_factories[index]->factor();
                }
                break;
            }

            case 0: {
                return 0;
            }
            default: {
                std::cout << "Invalid choice." << std::endl;
                break;
            }
        }
    }
}