
def create_flag(flag):
    with open('./flag.txt', 'w') as f:
        f.write(flag) 


